import os
import json
from datetime import datetime
from flask import Flask, render_template_string, request, redirect, url_for, session, jsonify

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "vercel_demo_secret_key")

# Hardcoded admin credentials (same as original)
ADMIN_USERNAME = "DGDRIFT"
ADMIN_PASSWORD = "DRIFT_SHIVANI"

# ---------- Routes ----------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['username'] = ADMIN_USERNAME
            return redirect(url_for("dashboard"))
        else:
            error = "Invalid username or password. Only admin access."
            return render_template_string(LOGIN_PAGE, error=error)
    return render_template_string(LOGIN_PAGE, error=None)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
def dashboard():
    if 'username' not in session or session['username'] != ADMIN_USERNAME:
        return redirect(url_for("login"))

    # Since Vercel has no persistent file system, we return a demo message
    # showing what would be shown if real servers existed.
    servers = [
        {
            "name": "demo-server-1",
            "display_name": "Demo Server (Vercel)",
            "running": False,
            "has_files": False,
            "config": {"type": "web", "port": 8080},
            "created_at": str(datetime.now())
        }
    ]
    return render_template_string(DASHBOARD_HTML, servers=servers)

# API endpoints – these are now read‑only or return friendly messages
@app.route("/api/server/<action>/<name>", methods=["POST"])
def server_action(action, name):
    if 'username' not in session or session['username'] != ADMIN_USERNAME:
        return jsonify({"error": "Not authenticated"}), 401
    # On Vercel, actions are disabled
    return jsonify({"error": f"Action '{action}' is not available on serverless platform. Please use a VPS for full functionality."}), 400

@app.route("/api/logs/<name>")
def get_logs(name):
    if 'username' not in session or session['username'] != ADMIN_USERNAME:
        return "", 401
    return "Logs are not available on Vercel (no persistent storage)."

@app.route("/api/stats")
def get_stats():
    if 'username' not in session or session['username'] != ADMIN_USERNAME:
        return jsonify({})
    return jsonify({
        "total_servers": 1,   # demo
        "running_servers": 0,
        "unlimited": False,
        "message": "Demo mode on Vercel - full features require a VPS"
    })

@app.route("/health")
def health_check():
    return jsonify({"status": "healthy", "timestamp": str(datetime.now())})

# ---------- Embedded HTML (simplified dashboard, identical to original but with disabled controls) ----------
LOGIN_PAGE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DRIFT Hosting | Admin Login</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Montserrat', sans-serif;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            background: rgba(0,0,0,0.8);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 20px;
            width: 90%;
            max-width: 400px;
            text-align: center;
            box-shadow: 0 0 50px rgba(0,100,255,0.5);
        }
        .logo {
            font-size: 2.5rem;
            font-weight: 700;
            background: linear-gradient(to right, #0099ff, #00d4ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }
        input {
            width: 100%;
            padding: 15px;
            margin: 10px 0;
            border: 2px solid #0099ff;
            border-radius: 10px;
            background: rgba(255,255,255,0.1);
            color: white;
        }
        button {
            width: 100%;
            padding: 15px;
            background: linear-gradient(45deg, #0099ff, #00d4ff);
            border: none;
            border-radius: 10px;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        .error { color: #ff6b6b; margin-top: 15px; }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">DRIFT Hosting</div>
        <div class="tagline">Admin Control Panel</div>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login as Admin</button>
            {% if error %}<div class="error">{{ error }}</div>{% endif %}
        </form>
    </div>
</body>
</html>
'''

DASHBOARD_HTML = '''
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DRIFT Hosting | Dashboard (Demo)</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: #0a0f1f;
            font-family: 'Poppins', sans-serif;
            color: white;
            padding: 2rem;
        }
        .navbar {
            background: rgba(5,10,25,0.95);
            padding: 1rem 2rem;
            border-bottom: 1px solid #0099ff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            margin-bottom: 2rem;
        }
        .logo-text {
            font-size: 1.6rem;
            font-family: 'Orbitron', monospace;
            background: linear-gradient(135deg, #0099ff, #00d4ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .logout-btn {
            background: rgba(255,71,87,0.15);
            border: 1px solid #ff4757;
            color: #ff6b6b;
            padding: 8px 20px;
            border-radius: 25px;
            text-decoration: none;
        }
        .hero-section {
            text-align: center;
            margin-bottom: 2rem;
        }
        .hero-title {
            font-size: 3rem;
            font-family: 'Orbitron', monospace;
        }
        .hero-title span { background: linear-gradient(135deg, #0099ff, #00d4ff); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; }
        .demo-alert {
            background: rgba(255,170,0,0.2);
            border: 1px solid #ffaa00;
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 2rem;
            text-align: center;
        }
        .server-card {
            background: rgba(5,10,30,0.6);
            border: 1px solid rgba(0,150,255,0.2);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            max-width: 600px;
        }
        button {
            background: transparent;
            border: 1px solid #0099ff;
            color: #0099ff;
            padding: 6px 12px;
            border-radius: 8px;
            margin-right: 8px;
            cursor: pointer;
        }
        button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        footer { text-align: center; margin-top: 2rem; color: #6688aa; }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo-text">DRIFT <span style="font-size:0.8rem;">(Vercel Demo)</span></div>
        <a href="/logout" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
    <div class="hero-section">
        <h1 class="hero-title">DRIFT <span>Unlimited</span> Hosting</h1>
        <p>Demo mode on Vercel – full features require a VPS (DigitalOcean, Hetzner, etc.)</p>
    </div>
    <div class="demo-alert">
        <i class="fas fa-info-circle"></i> <strong>Serverless Limitations:</strong> Starting/stopping servers, file uploads, and logs are disabled on Vercel. This is a static demo.
    </div>
    <h2>Your Servers (Demo)</h2>
    {% for server in servers %}
    <div class="server-card">
        <h3>{{ server.display_name }}</h3>
        <p>Status: {% if server.running %}RUNNING{% else %}STOPPED{% endif %}</p>
        <p>Type: {{ server.config.type }} | Port: {{ server.config.port }}</p>
        <button disabled><i class="fas fa-play"></i> Start</button>
        <button disabled><i class="fas fa-stop"></i> Stop</button>
        <button disabled><i class="fas fa-sync-alt"></i> Restart</button>
        <button disabled><i class="fas fa-terminal"></i> Logs</button>
        <button disabled><i class="fas fa-trash"></i> Delete</button>
    </div>
    {% endfor %}
    <footer>
        <p>For the real DRIFT Hosting experience (unlimited servers, process control), deploy on a traditional VPS.</p>
    </footer>
</body>
</html>
'''

if __name__ == "__main__":
    # This block is ignored on Vercel, but used for local testing.
    port = int(os.environ.get("PORT", 8030))
    app.run(host="0.0.0.0", port=port, debug=False)